
# TrackFit Project Documentation

## Project Overview
TrackFit is a fitness tracking application designed to monitor calorie intake and physical activities. This project includes a frontend developed in React and a backend built with Flask.

---

## Installation Instructions

### 1. Prerequisites
- **Node.js**: Install the latest version from [Node.js Official Site](https://nodejs.org/).
- **Python**: Ensure Python 3.8 or higher is installed. Download from [Python Official Site](https://www.python.org/).
- **Git**: Optional but recommended for version control.
- **Database**: SQLite (included in Python) or MySQL.

---

### 2. Setting Up the Backend
1. Navigate to the `TrackFit/backend` directory:
   ```bash
   cd TrackFit/backend
   ```
2. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # Windows: venv\Scripts\activate
   ```
3. Install the required dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Configure the database:
   - Create the database using the `schemas.sql` file located in `TrackFit/database`:
     ```bash
     sqlite3 database.db < ../database/schemas.sql
     ```
   - Or import the schema into your MySQL database if using MySQL.

5. Start the backend server:
   ```bash
   flask run
   ```
   - Access it at [http://127.0.0.1:5000](http://127.0.0.1:5000).

---

### 3. Setting Up the Frontend
1. Navigate to the `TrackFit/frontend` directory:
   ```bash
   cd TrackFit/frontend
   ```
2. Install the required Node.js dependencies:
   ```bash
   npm install
   ```
3. Start the frontend development server:
   ```bash
   npm start
   ```
   - The application will run at [http://localhost:3000](http://localhost:3000).

---

## Testing the Application
1. Open the frontend in your browser ([http://localhost:3000](http://localhost:3000)).
2. Register and log in as a new user.
3. Use the dashboard to track calories, set goals, and monitor activities.

---

## Troubleshooting
- **Backend Issues**: Ensure the virtual environment is activated and all dependencies are installed correctly.
- **Frontend Issues**: Delete `node_modules` and run `npm install` again.
- **Database Issues**: Check the database connection and ensure the schema is loaded correctly.

---

## Additional Notes
- This project uses Flask for backend APIs and React for frontend UI.
- Future enhancements include mobile app support and wearable integrations.
